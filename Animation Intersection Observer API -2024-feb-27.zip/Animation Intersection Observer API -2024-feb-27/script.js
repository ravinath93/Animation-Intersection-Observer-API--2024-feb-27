
let observer = new IntersectionObserver((entries,observer) => {

  entries.filter(e => e.isIntersecting).forEach(entry => {
    entry.target.classList.add("scrolled");
    observer.unobserve(entry.target);
  });
});




// observe list ###

document.querySelectorAll('p')
.forEach(e => {
  observer.observe(e)
});

document.querySelectorAll('img')
.forEach(e => {
  observer.observe(e)
});

document.querySelectorAll('.container-1')
.forEach(e => {
  observer.observe(e)
});